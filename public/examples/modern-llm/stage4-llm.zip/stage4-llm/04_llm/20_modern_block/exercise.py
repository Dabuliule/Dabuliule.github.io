"""阶段四：把 RMSNorm、SwiGLU 接入已有 RoPE 模型。

运行：.venv/bin/python 04_llm/20_modern_block/exercise.py
复用第 17 课的前向与缓存逻辑，只替换组件；不加载旧模型权重。
这是教学模型，仍使用 MHA，不是某个实际 LLM 的精确复现。
"""

import importlib.util
from pathlib import Path

import torch
from torch import nn
import torch.nn.functional as F


STAGE = Path(__file__).resolve().parents[1]


def load(name, directory):
    spec = importlib.util.spec_from_file_location(name, STAGE / directory / "exercise.py")
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


rope = load("rope_cache", "17_rope_cache")
RMSNorm = load("rmsnorm", "18_rmsnorm").RMSNorm
SwiGLU = load("swiglu", "19_swiglu").SwiGLU


class ModernBlock(rope.RoPEBlock):
    def __init__(self):
        super().__init__()
        # 父类已创建注意力投影、RoPE 频率、LayerNorm 与旧 FFN。
        # 两个归一化层分别学习自己的缩放参数。
        self.attention_norm = RMSNorm(32)
        self.ffn_norm = RMSNorm(32)
        # 本实验保持中间维度方便观察结构；不声称与旧 FFN 参数量相同。
        self.ffn = SwiGLU(32, 64)

    # 继承前向函数：
    # h = x + AttentionWithRoPE(attention_norm(x))
    # output = h + ffn(ffn_norm(h))
    # 这里的 AttentionWithRoPE 只是说明流程，并非需要实现的新函数。


class ModernModel(rope.RoPEModel):
    def __init__(self):
        super().__init__()
        self.layers = nn.ModuleList([ModernBlock() for _ in range(2)])
        self.final_norm = RMSNorm(32)
        # embedding、输出层及模型 forward 直接继承。


def check_structure(model):
    assert isinstance(model.layers, nn.ModuleList) and len(model.layers) == 2
    assert isinstance(model.final_norm, RMSNorm)
    for block in model.layers:
        assert isinstance(block, ModernBlock)
        assert isinstance(block.attention_norm, RMSNorm)
        assert isinstance(block.ffn_norm, RMSNorm)
        assert block.attention_norm is not block.ffn_norm
        assert isinstance(block.ffn, SwiGLU)
        assert block.ffn.up_proj.weight.shape == (64, 32)
        assert block.ffn.down_proj.weight.shape == (32, 64)
    assert model.layers[0] is not model.layers[1]
    assert model.layers[0].ffn.up_proj.weight is not model.layers[1].ffn.up_proj.weight
    assert not any(isinstance(layer, nn.LayerNorm) for layer in model.modules())


@torch.no_grad()
def check_cache(model):
    model.eval()
    full_ids = torch.tensor([[1, 2, 3, 4]])
    _, caches = model(full_ids)
    # 同时检查单 token decode 与一次追加多个 token 时的因果遮罩。
    for new_ids in [torch.tensor([[5]]), torch.tensor([[6, 7]])]:
        cached_logits, caches = model(new_ids, caches)
        full_ids = torch.cat([full_ids, new_ids], dim=1)
        full_logits, full_caches = model(full_ids)
        reference = full_logits[:, -new_ids.shape[1]:, :]
        error = (cached_logits - reference).abs().max().item()
        assert torch.allclose(cached_logits, reference, atol=1e-6, rtol=1e-5)
        for (k, v), (ref_k, ref_v) in zip(caches, full_caches):
            assert k.shape == v.shape == (1, 4, full_ids.shape[1], 8)
            assert torch.allclose(k, ref_k, atol=1e-6, rtol=1e-5)
            assert torch.allclose(v, ref_v, atol=1e-6, rtol=1e-5)
        print(f"追加 {new_ids.shape[1]} 个 token，前缀长度 {full_ids.shape[1]}，logits 最大差 {error:.3g}")


def main():
    torch.manual_seed(42)
    torch.set_num_threads(1)
    model = ModernModel()
    check_structure(model)
    print("结构检查通过：RoPE + RMSNorm + SwiGLU，保留 MHA。")
    tokens = torch.tensor([[0, 1, 2, 3, 4], [2, 3, 4, 5, 6]])
    model.train()
    logits, _ = model(tokens[:, :-1])
    assert logits.shape == (2, 4, 8)
    loss = F.cross_entropy(logits.reshape(-1, 8), tokens[:, 1:].reshape(-1))
    model.zero_grad()
    loss.backward()
    for name, parameter in model.named_parameters():
        assert parameter.grad is not None, f"参数未接入计算图：{name}"
        assert torch.isfinite(parameter.grad).all(), name
    print(f"logits shape：{tuple(logits.shape)}；loss={loss.item():.6f}；所有参数梯度有限。")
    check_cache(model)
    print("整合检查通过！这是计算正确性检查，不证明新结构的训练效果优于旧结构。")


if __name__ == "__main__":
    main()
