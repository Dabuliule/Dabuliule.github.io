"""阶段四：贪心选择与概率采样。

运行：.venv/bin/python 04_llm/07_sampling/exercise.py
固定同一份概率，不训练模型；重复抽样是独立实验，不是连续生成文本。
"""

import torch


def choose_greedy(probabilities: torch.Tensor) -> torch.Tensor:
    """probabilities [B,V] → token_ids [B,1]，沿词表维选择最大值。"""
    # TODO 1：argmax，保留被归约的维度。
    return torch.argmax(probabilities, dim=-1, keepdim=True)


def choose_sample(probabilities: torch.Tensor) -> torch.Tensor:
    """probabilities [B,V] → token_ids [B,1]，每行按概率抽一个 ID。

    输入为合法概率分布。不要在函数内部重设随机种子。
    """
    # TODO 2：使用 torch.multinomial，每行抽一个样本。
    return torch.multinomial(probabilities, num_samples=1)


def main():
    torch.manual_seed(42)  # 只在实验开始设置一次，便于复现。
    torch.set_num_threads(1)
    vocab = ["茶", "水", "咖啡"]
    probabilities = torch.tensor([[0.5, 0.3, 0.2]])  # [1,3]
    greedy = choose_greedy(probabilities)
    sampled = choose_sample(probabilities)
    assert greedy.shape == sampled.shape == (1, 1)
    assert greedy.dtype == sampled.dtype == torch.long
    assert greedy.item() == 0
    assert 0 <= sampled.item() < len(vocab)
    print("固定概率：", probabilities.tolist())
    print("贪心选择：", vocab[greedy.item()])
    print("一次采样：", vocab[sampled.item()])

    # 批量构造一万份相同分布，每行独立抽一次。
    # repeat 复制概率，不是把某次抽样结果重复一万次。
    repetitions = 10_000
    repeated = probabilities.repeat(repetitions, 1)  # [10000,3]
    greedy_ids = choose_greedy(repeated)
    sampled_ids = choose_sample(repeated)
    assert greedy_ids.shape == sampled_ids.shape == (repetitions, 1)
    assert torch.all(greedy_ids == 0)
    assert sampled_ids.dtype == torch.long
    assert torch.all((sampled_ids >= 0) & (sampled_ids < len(vocab)))

    # 统计部分已准备好：bincount 数出每种 ID 出现了多少次。
    counts = torch.bincount(sampled_ids.flatten(), minlength=len(vocab))
    frequencies = counts.float() / repetitions
    print("\n同一分布重复采样一万次：")
    for index, token in enumerate(vocab):
        print(f"{token}：目标概率 {probabilities[0, index]:.1%}，"
              f"实际频率 {frequencies[index]:.1%}（{counts[index].item()} 次）")
    # 统计性检查：允许波动，不要求次数精确等于 5000、3000、2000。
    assert torch.all((frequencies - probabilities[0]).abs() < 0.03), "采样频率偏差过大。"

    # 不同行有不同分布，检查确实是每行独立选择。
    certain = torch.tensor([[0.0, 1.0, 0.0], [0.0, 0.0, 1.0]])
    expected = torch.tensor([[1], [2]])
    assert torch.equal(choose_greedy(certain), expected)
    assert torch.equal(choose_sample(certain), expected)
    print("检查通过！")


if __name__ == "__main__":
    main()

# 思考：为什么一次抽到“咖啡”不表示模型认为“咖啡”最可能？
# 真正生成时，为什么不能一直使用同一份概率来抽后续 token？
