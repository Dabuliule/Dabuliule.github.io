"""阶段四第三课：简化的 BPE 训练循环。

运行：python3 04_llm/03_bpe_training/exercise.py
复用前两课函数，只学习有序合并规则，不构建 token ID 词表。
"""

import importlib.util
from pathlib import Path


def load_exercise(directory):
    path = Path(__file__).resolve().parents[1] / directory / "exercise.py"
    spec = importlib.util.spec_from_file_location(directory, path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


merge_pair = load_exercise("01_bpe_merge").merge_pair
count_pairs = load_exercise("02_bpe_pair_counts").count_pairs


def train_bpe(
    corpus: list[tuple[list[str], int]], num_merges: int
) -> tuple[list[tuple[str, str]], list[tuple[list[str], int]]]:
    """返回 (有序规则列表, 最终语料切分)，不修改原始输入。

    假设 num_merges >= 0，单词频次为正整数。
    最多合并 num_merges 轮；没有相邻对时提前结束。
    频次并列时，选 count_pairs 返回的字典中最先出现的对。
    """
    current = [(tokens.copy(), freq) for tokens, freq in corpus]
    merges = []

    for _ in range(num_merges):
        counts = count_pairs(current)
        if not counts:
            break
        pair = max(counts, key=counts.get)
        merges.append(pair)
        current = [(merge_pair(tokens, pair), freq) for tokens, freq in current]

    return merges, current


def main():
    corpus = [
        (["h", "u", "g"], 10),
        (["p", "u", "g"], 5),
        (["p", "u", "n"], 12),
        (["b", "u", "n"], 4),
    ]
    original = [(tokens.copy(), freq) for tokens, freq in corpus]
    merges, final_corpus = train_bpe(corpus, 2)
    print("学习到的规则：", merges)
    print("最终切分：", final_corpus)
    assert merges == [("p", "u"), ("pu", "n")]
    assert final_corpus == [
        (["h", "u", "g"], 10),
        (["pu", "g"], 5),
        (["pun"], 12),
        (["b", "u", "n"], 4),
    ]
    assert corpus == original, "不能修改传入的语料。"
    assert train_bpe(corpus, 0) == ([], corpus)
    assert train_bpe([], 3) == ([], [])
    assert train_bpe([(["x"], 2)], 3) == ([], [(["x"], 2)])
    assert train_bpe([(["a", "b"], 2)], 5) == (
        [("a", "b")], [(["ab"], 2)]
    ), "合并完后没有相邻对，应提前停止。"
    assert train_bpe([(["a", "b", "c"], 1)], 1) == (
        [("a", "b")], [(["ab", "c"], 1)]
    ), "频次并列时选择最先出现的对。"
    print("检查通过！")


if __name__ == "__main__":
    main()
