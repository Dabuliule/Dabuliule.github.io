"""阶段四：RMSNorm 控制每个 token 的隐藏向量尺度。

运行：.venv/bin/python 04_llm/18_rmsnorm/exercise.py
本课使用 float32，不处理混合精度；不改现有模型。
"""

import torch
from torch import nn
import torch.nn.functional as F


class RMSNorm(nn.Module):
    def __init__(self, hidden_size, eps=1e-6):
        super().__init__()
        self.eps = eps
        # TODO 1：创建可学习的 weight，shape [hidden_size]，初始全为 1。
        # 使用 nn.Parameter(torch.ones(...))，本课没有 bias。
        self.weight = nn.Parameter(torch.ones(hidden_size))

    def forward(self, x):
        """x [B,L,D] → y [B,L,D]；沿 D 归一化，不混合不同 token。"""
        # TODO 2：平方后沿最后一维求平均，keepdim=True，得到 [B,L,1]。
        # TODO 3：先加 self.eps 再开平方，得到 denominator [B,L,1]。
        # TODO 4：返回 x / denominator * self.weight。
        squared = x ** 2
        mean = squared.mean(dim=-1, keepdim=True)
        denominator = torch.sqrt(mean + self.eps)
        return x / denominator * self.weight


def main():
    norm = RMSNorm(2)
    assert isinstance(norm.weight, nn.Parameter), "请创建可学习参数。"
    assert norm.weight.shape == (2,)
    assert torch.equal(norm.weight, torch.ones(2))
    x = torch.tensor([[[3., 4.], [30., 40.], [0., 0.]]])  # [1,3,2]
    original = x.clone()
    y = norm(x)
    assert y.shape == x.shape
    assert torch.equal(x, original)
    assert torch.isfinite(y).all()
    assert torch.equal(y[:, 2], torch.zeros(1, 2))
    assert torch.allclose(y[:, 0], torch.tensor([[0.848528, 1.131371]]), atol=1e-6)
    assert torch.allclose(y[:, 0], y[:, 1], atol=1e-6)
    print("输入：", x.tolist())
    print("RMSNorm（weight=1）：", y.detach().tolist())
    print("各 token 输出均值：", y.mean(dim=-1).detach().tolist())
    print("各 token 输出 RMS：", y.square().mean(dim=-1).sqrt().detach().tolist())
    layer_norm = F.layer_norm(x, (2,), eps=norm.eps)
    print("LayerNorm（无仿射参数）：", layer_norm.tolist())

    # 改变可学习缩放，展示归一化之后仍可以调整各分量。
    with torch.no_grad():
        norm.weight.copy_(torch.tensor([2., 0.5]))
    scaled = norm(x)
    assert torch.allclose(scaled, y * torch.tensor([2., 0.5]))
    print("RMSNorm（weight=[2,0.5]）：", scaled.detach().tolist())

    # 使用多 batch、多 token 的输入，逐个向量独立核对数值。
    torch.manual_seed(42)
    probe = torch.randn(2, 3, 2, requires_grad=True)
    actual = norm(probe)
    reference = torch.stack([
        torch.stack([row / torch.sqrt(torch.dot(row, row) / 2 + norm.eps) * norm.weight
                     for row in sample])
        for sample in probe
    ])
    assert torch.allclose(actual, reference, atol=1e-6)
    actual.sum().backward()
    assert probe.grad is not None and torch.isfinite(probe.grad).all()
    assert norm.weight.grad is not None and torch.isfinite(norm.weight.grad).all()
    assert norm.weight.grad.abs().sum() > 0
    print("数值、shape、零输入和梯度检查通过！")


if __name__ == "__main__":
    main()
