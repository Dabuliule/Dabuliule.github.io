"""阶段四：temperature 怎样影响采样概率。

运行：.venv/bin/python 04_llm/08_temperature/exercise.py
固定 logits，复用上一课的采样函数，不训练模型。
"""

import importlib.util
from pathlib import Path

import torch


path = Path(__file__).resolve().parents[1] / "07_sampling" / "exercise.py"
spec = importlib.util.spec_from_file_location("sampling", path)
module = importlib.util.module_from_spec(spec)
spec.loader.exec_module(module)
choose_sample = module.choose_sample
choose_greedy = module.choose_greedy


def temperature_probs(logits: torch.Tensor, temperature: float) -> torch.Tensor:
    """logits [B,V] → probabilities [B,V]。

    假设 logits 有限，temperature 是有限实数。
    本函数只接受正温度，temperature <= 0 时抛出 ValueError。
    不修改输入，不在这里采样。
    """
    # TODO 1：检查温度必须大于 0。
    # TODO 2：用 logits 除以温度，再沿词表维做 softmax，返回概率。
    if temperature <= 0:
        raise ValueError("temperature 必须是正数。")
    return torch.softmax(logits / temperature, dim=-1)


def main():
    torch.manual_seed(42)
    torch.set_num_threads(1)
    logits = torch.tensor([[2.0, 1.0, 0.0]])  # [1,3]：茶、水、咖啡
    original = logits.clone()
    vocab = ["茶", "水", "咖啡"]
    expected = {
        0.5: [0.8668133, 0.1173104, 0.0158762],
        1.0: [0.6652410, 0.2447285, 0.0900306],
        2.0: [0.5064804, 0.3071959, 0.1863237],
    }
    for temperature in [0.5, 1.0, 2.0]:
        probabilities = temperature_probs(logits, temperature)
        assert probabilities.shape == (1, 3)
        assert torch.allclose(probabilities.sum(dim=-1), torch.ones(1))
        assert torch.allclose(probabilities[0], torch.tensor(expected[temperature]), atol=1e-6)
        greedy = choose_greedy(probabilities)
        assert greedy.item() == 0, "正温度不会改变最大分数的位置。"

        sampled = choose_sample(probabilities.repeat(10_000, 1))
        counts = torch.bincount(sampled.flatten(), minlength=3)
        frequencies = counts.float() / sampled.shape[0]
        print(f"\nT={temperature}，贪心选择：{vocab[greedy.item()]}")
        for i, token in enumerate(vocab):
            print(f"{token}：概率 {probabilities[0, i]:.1%}，采样频率 {frequencies[i]:.1%}")
        assert torch.all((frequencies - probabilities[0]).abs() < 0.03)

    # 每行独立归一化，不能在 batch 维上做 softmax。
    batch_logits = torch.tensor([[2.0, 1.0, 0.0], [0.0, 1.0, 2.0]])
    batch_probs = temperature_probs(batch_logits, 2.0)
    assert batch_probs.shape == (2, 3)
    assert torch.allclose(batch_probs[0], torch.tensor(expected[2.0]), atol=1e-6)
    assert torch.allclose(batch_probs[1], batch_probs[0].flip(0))
    assert torch.equal(logits, original), "不能原地修改 logits。"
    for invalid in [0.0, -1.0]:
        try:
            temperature_probs(logits, invalid)
        except ValueError:
            pass
        else:
            raise AssertionError("本函数对非正温度应抛出 ValueError。")
    print("\n检查通过！")


if __name__ == "__main__":
    main()

# 思考：温度升高后，低概率 token 更容易出现，为什么不代表回答一定更好？
