"""阶段四第五课：BPE token 与整数 ID 的转换。

运行：python3 04_llm/05_bpe_token_ids/exercise.py
本课使用固定词表，返回 Python list[int]，暂不创建 Tensor。
未知字符直接报错，不动态扩充词表；不处理特殊 token。
"""

import importlib.util
from pathlib import Path


path = Path(__file__).resolve().parents[1] / "04_bpe_encoding" / "exercise.py"
spec = importlib.util.spec_from_file_location("bpe_encoding", path)
module = importlib.util.module_from_spec(spec)
spec.loader.exec_module(module)
encode_word = module.encode_word

# 基础字符必须保留；再加入每次合并产生的 token。
VOCAB = ["b", "g", "h", "n", "p", "u", "pu", "pun"]
MERGES = [("p", "u"), ("pu", "n")]


def build_vocab(vocab: list[str]) -> tuple[dict[str, int], dict[int, str]]:
    """按 vocab 列表顺序分配从 0 开始的 ID。假设 token 不重复。"""
    # TODO 1：构建 token_to_id 和 id_to_token 两个字典，并返回它们。
    # 提示：enumerate(vocab) 可以同时得到索引和 token。
    token_to_id = {token: i for i, token in enumerate(vocab)}
    id_to_token = {i: token for i, token in enumerate(vocab)}
    return token_to_id, id_to_token


def encode_ids(
    word: str, merges: list[tuple[str, str]], token_to_id: dict[str, int]
) -> list[int]:
    """先用固定 BPE 规则切分，再查询每个 token 的 ID。

    不在词表中的 token 应触发 KeyError，不允许忽略或临时添加。
    """
    # TODO 2：调用 encode_word，再把 token 列表映射成 ID 列表。
    tokens = encode_word(word, merges)
    return [token_to_id[token] for token in tokens]


def decode_ids(ids: list[int], id_to_token: dict[int, str]) -> str:
    """逐个 ID 查出 token，然后拼接成原文。无效 ID 应触发 KeyError。"""
    # TODO 3：反向查表，用空字符串的 join 方法拼接各 token。
    return "".join(id_to_token[id] for id in ids)


def main():
    token_to_id, id_to_token = build_vocab(VOCAB)
    assert token_to_id == {
        "b": 0, "g": 1, "h": 2, "n": 3,
        "p": 4, "u": 5, "pu": 6, "pun": 7,
    }
    assert id_to_token == dict(enumerate(VOCAB))
    original = token_to_id.copy()
    for word, expected in [
        ("pung", [7, 1]),
        ("pug", [6, 1]),
        ("hug", [2, 5, 1]),
        ("pupu", [6, 6]),
        ("", []),
    ]:
        ids = encode_ids(word, MERGES, token_to_id)
        restored = decode_ids(ids, id_to_token)
        print(f"{word!r} → {ids} → {restored!r}")
        assert ids == expected
        assert restored == word

    # 解码只查表拼接，不需要倒着执行 BPE 合并规则。
    assert decode_ids([4, 5, 3], id_to_token) == "pun"
    assert decode_ids([7], id_to_token) == "pun"

    for action in (
        lambda: encode_ids("z", MERGES, token_to_id),
        lambda: decode_ids([99], id_to_token),
    ):
        try:
            action()
        except KeyError:
            pass
        else:
            raise AssertionError("未知 token 或无效 ID 应报 KeyError。")
    assert token_to_id == original, "编码不能修改固定词表。"
    print("检查通过！")


if __name__ == "__main__":
    main()
