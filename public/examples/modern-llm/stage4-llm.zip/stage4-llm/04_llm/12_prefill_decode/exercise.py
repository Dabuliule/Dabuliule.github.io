"""阶段四：观察 prefill 与 decode 的输入和缓存长度。

运行：.venv/bin/python 04_llm/12_prefill_decode/exercise.py
复用现有 NextCharModel 架构，随机初始化；数字仅表示 token ID。
不训练、不评价预测质量；固定生成 3 个 ID，本实验不定义 EOS。
"""

import importlib.util
from pathlib import Path

import torch


path = Path(__file__).resolve().parents[2] / "experiments/text_completion/train.py"
spec = importlib.util.spec_from_file_location("text_model", path)
module = importlib.util.module_from_spec(spec)
spec.loader.exec_module(module)
NextCharModel = module.NextCharModel


def show_cache(cache, expected_length):
    assert len(cache) == 2
    for layer, (keys, values) in enumerate(cache):
        print(f"  第 {layer} 层：K {tuple(keys.shape)}，V {tuple(values.shape)}")
        assert keys.shape == values.shape == (1, 4, expected_length, 8)


@torch.no_grad()
def main():
    torch.manual_seed(42)
    torch.set_num_threads(1)
    model = NextCharModel(vocab_size=8, num_layers=2)
    model.eval()
    prompt = torch.tensor([[1, 2, 3, 4]], dtype=torch.long)  # [1,4]

    # TODO 1：prefill。把完整 prompt 传给 model，接收 logits 和 cache。
    logits, cache = model(prompt)
    if logits is Ellipsis or cache is Ellipsis:
        raise NotImplementedError("请完成 prefill 模型调用。")
    assert logits.shape == (1, 4, 8)
    print(f"prefill：输入 {tuple(prompt.shape)}，logits {tuple(logits.shape)}")
    show_cache(cache, expected_length=4)

    # 第一个新 token 直接来自 prefill 的最后位置输出。
    next_id = logits[:, -1, :].argmax(dim=-1, keepdim=True)  # [1,1]
    generated = torch.cat([prompt, next_id], dim=1)
    print(f"选出第 1 个新 token：{next_id.item()}；文本已有 {generated.shape[1]} 个 ID，缓存仍为 4。")

    for step in range(2, 4):
        old_cache = cache
        old_length = cache[0][0].shape[2]
        decode_input = next_id.clone()  # [1,1]，上一步刚选出的 token
        # TODO 2：decode。只传 decode_input 和旧 cache，接收新 logits 和 cache。
        # 不要传整个 generated；它的历史部分已经在缓存里。
        logits, cache = model(decode_input, old_cache)
        if logits is Ellipsis or cache is Ellipsis:
            raise NotImplementedError("请完成 decode 模型调用。")
        assert logits.shape == (1, 1, 8)
        print(f"\ndecode：输入 ID {decode_input.item()}，shape {tuple(decode_input.shape)}，"
              f"logits {tuple(logits.shape)}")
        show_cache(cache, expected_length=old_length + 1)
        for (old_k, old_v), (new_k, new_v) in zip(old_cache, cache):
            assert torch.equal(old_k, new_k[:, :, :old_length, :])
            assert torch.equal(old_v, new_v[:, :, :old_length, :])
        next_id = logits[:, -1, :].argmax(dim=-1, keepdim=True)
        generated = torch.cat([generated, next_id], dim=1)
        print(f"选出第 {step} 个新 token：{next_id.item()}；"
              f"文本已有 {generated.shape[1]} 个 ID，缓存为 {cache[0][0].shape[2]}。")

    assert generated.shape == (1, 7)
    assert cache[0][0].shape[2] == 6
    print("\n最终 ID 序列：", generated.tolist())
    print("3 个新 token = 1 次 prefill 的输出 + 2 次 decode 的输出。")
    print("最后选出的 token 没有再次输入模型，所以缓存不包含它。检查通过！")


if __name__ == "__main__":
    main()
