"""阶段四：KV Cache 与完整前缀重算是否等价。

运行：.venv/bin/python 04_llm/13_cache_equivalence/exercise.py
复用既有模型；随机参数即可验证计算等价性，不训练、不采样。
固定后续 ID，让两条计算路径始终接收同一段文本。
"""

import importlib.util
from pathlib import Path

import torch


path = Path(__file__).resolve().parents[2] / "experiments/text_completion/train.py"
spec = importlib.util.spec_from_file_location("text_model", path)
module = importlib.util.module_from_spec(spec)
spec.loader.exec_module(module)
NextCharModel = module.NextCharModel


@torch.no_grad()
def main():
    torch.manual_seed(42)
    torch.set_num_threads(1)
    model = NextCharModel(vocab_size=8, num_layers=2)
    model.eval()
    prompt = torch.tensor([[1, 2, 3, 4]], dtype=torch.long)
    _, cache = model(prompt)  # prefill，缓存长度为 4。
    full_ids = prompt.clone()
    cached_work = full_work = 0

    for token_id in [7, 1, 2]:
        new_id = torch.tensor([[token_id]], dtype=torch.long)  # [1,1]
        full_ids = torch.cat([full_ids, new_id], dim=1)        # [1,L]

        # TODO 1：缓存路径：输入 new_id 和旧 cache，接收 cached_logits、新 cache。
        # cached_logits: [1,1,8]。
        cached_logits, cache = model(new_id, cache)
        if cached_logits is Ellipsis or cache is Ellipsis:
            raise NotImplementedError("请完成缓存路径。")

        # TODO 2：重算路径：只输入 full_ids，不传 cache；忽略返回的新缓存。
        # full_logits: [1,L,8]。
        full_logits = model(full_ids)[0]
        if full_logits is Ellipsis:
            raise NotImplementedError("请完成完整前缀重算路径。")

        # TODO 3：分别取最后位置的全部词表分数，两者都是 [1,8]。
        cached_last = cached_logits[:, -1, :]
        full_last = full_logits[:, -1, :]
        if cached_last is Ellipsis or full_last is Ellipsis:
            raise NotImplementedError("请完成最后位置切片。")

        assert cached_logits.shape == (1, 1, 8)
        assert full_logits.shape == (1, full_ids.shape[1], 8)
        assert cached_last.shape == full_last.shape == (1, 8)
        assert torch.equal(cached_last, cached_logits[:, -1, :])
        assert torch.equal(full_last, full_logits[:, -1, :])
        for k, v in cache:
            assert k.shape == v.shape == (1, 4, full_ids.shape[1], 8)
        error = (cached_last - full_last).abs().max().item()
        print(f"前缀长度 {full_ids.shape[1]}：缓存路径输入 1 个 ID，"
              f"重算路径输入 {full_ids.shape[1]} 个 ID；logits 最大绝对差 {error:.8g}")
        assert torch.allclose(cached_last, full_last, atol=1e-6, rtol=1e-5)
        cached_work += new_id.numel()
        full_work += full_ids.numel()

    print(f"\nprefill 之后三次调用的输入位置总数：缓存路径 {cached_work}，重算路径 {full_work}。")
    print("这不是耗时或 FLOPs 的倍数：新 token 的注意力仍要读取历史 K/V。")
    print("同一模型、同一前缀下，两条计算路径的 logits 在浮点容差内一致。检查通过！")


if __name__ == "__main__":
    main()

# 思考：decode 时为何要用历史长度作为新 token 的位置索引偏移？
# 若只比较 argmax，相同的 token ID 能否证明两份分数一致？
