"""生成策略整合：同一个模型、同一个 prompt，只改变 token 选择方式。

运行：.venv/bin/python 04_llm/11_generation_strategies/exercise.py
复用 experiments/text_completion 的训练组件与带 KV Cache 的 complete。
训练只执行一次；小型字符语料仅用于观察机制，不评价通用语言能力。
"""

import importlib.util
from pathlib import Path

import torch


ROOT = Path(__file__).resolve().parents[2]


def load(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


text_model = load("text_model", ROOT / "experiments/text_completion/train.py")
sampling = load("sampling", ROOT / "04_llm/07_sampling/exercise.py")
temperature_probs = load("temperature", ROOT / "04_llm/08_temperature/exercise.py").temperature_probs
top_k_probs = load("top_k", ROOT / "04_llm/09_top_k/exercise.py").top_k_probs
top_p_probs = load("top_p", ROOT / "04_llm/10_top_p/exercise.py").top_p_probs


def select_next(logits, strategy):
    """最后位置的 logits [1,V] → token ID [1,1]。

    为单独比较每种机制，top-k、top-p 的温度固定为 1。
    logits 中 pad 已设为 -inf，不得再生成它。
    """
    if strategy == "greedy":
        # TODO 1：沿词表维 argmax，保留维度。
        return torch.argmax(logits, dim=-1, keepdim=True)
    elif strategy == "temperature":
        # TODO 2：temperature_probs(logits, 1.5)，再用 choose_sample 抽样。
        return sampling.choose_sample(temperature_probs(logits, 1.5))
    elif strategy == "top_k":
        # TODO 3：top_k_probs(logits, 3)，再抽样。
        return sampling.choose_sample(top_k_probs(logits, 3))
    elif strategy == "top_p":
        # TODO 4：top_p_probs(logits, 0.9)，再抽样。
        return sampling.choose_sample(top_p_probs(logits, 0.9))
    raise ValueError(f"未知策略：{strategy}")


def main():
    strategies = ["greedy", "temperature", "top_k", "top_p"]
    # 先检查 TODO，避免训练后才发现未完成。
    for strategy in strategies:
        choice = select_next(torch.tensor([[0., 1., 2., float("-inf")]]), strategy)
        assert choice.shape == (1, 1) and choice.dtype == torch.long
        assert 0 <= choice.item() < 3

    torch.manual_seed(42)
    torch.set_num_threads(1)
    sentences = [line.strip() for line in (ROOT / "experiments/text_completion/corpus.txt").read_text().splitlines()
                 if line.strip()]
    vocab = ["<eos>"] + sorted(set("".join(sentences))) + ["<pad>"]
    token_to_id = {token: i for i, token in enumerate(vocab)}
    inputs, labels = text_model.make_data(sentences, token_to_id)
    model = text_model.NextCharModel(len(vocab))
    optimizer = torch.optim.Adam(model.parameters(), lr=0.01)
    for _ in range(300):
        loss = text_model.training_loss(model, inputs, labels)
        optimizer.zero_grad()
        loss.backward()
        optimizer.step()
    model.eval()
    print("模型训练完成；以下所有策略使用同一份参数。")

    # 短前缀往往允许多种后续，便于观察选择差异。
    prompt = "我"
    with torch.no_grad():
        logits, _ = model(text_model.make_context(prompt, token_to_id))
        last = logits[:, -1, :].clone()
        last[:, token_to_id["<pad>"]] = float("-inf")
        values, indices = last.softmax(dim=-1).topk(min(5, len(vocab)), dim=-1)
        print("首个生成位置的原始概率：", [(vocab[i], round(p, 4))
              for i, p in zip(indices[0].tolist(), values[0].tolist())])
        for strategy in strategies:
            print(f"\n{strategy}：")
            for seed in [10, 20, 30]:
                # 每段生成开始设置种子，不能在每个 token 的采样函数里重设。
                torch.manual_seed(seed)
                generated = text_model.complete(
                    model, prompt, token_to_id, vocab, max_new_chars=16,
                    select_token=lambda scores: select_next(scores, strategy),
                )
                assert "<pad>" not in generated and "<eos>" not in generated
                print(f"seed={seed}：{generated}")
    print("\n输出可能相同，也可能不同；不要求高温或采样一定产生更好的句子。")


if __name__ == "__main__":
    main()
