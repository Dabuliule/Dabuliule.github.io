"""阶段四：对每个头的多组二维分量同时应用旋转。

运行：.venv/bin/python 04_llm/16_rope_pairs/exercise.py
相邻分量配对；频率由外部传入，本课不学习频率表的构造。
"""

import torch


def apply_rope(x, positions, frequencies):
    """x [B,H,L,d]，positions [L]，frequencies [d/2] → [B,H,L,d]。

    假设 d 为偶数、shape 匹配、输入位于相同设备。
    frequencies 表示每组每前进一个位置旋转的弧度数。
    不修改输入；同一个函数分别用于 Q 和 K，允许两者头数不同。
    """
    B, H, L, d = x.shape
    # TODO 1：reshape 为 [B,H,L,d//2,2]，取出每组的 a、b。
    #         a、b 均为 [B,H,L,d//2]，不是取两个注意力头。
    # TODO 2：positions[:, None] * frequencies[None, :] 得到 angles [L,d//2]。
    # TODO 3：用 torch.cos / torch.sin 计算角度的余弦、正弦。
    #         [L,d//2] 自动广播到各个 batch 和 head。
    # TODO 4：a_new = a*cos - b*sin；b_new = a*sin + b*cos。
    # TODO 5：torch.stack([a_new,b_new], dim=-1)，再 reshape 回 [B,H,L,d]。
    x_reshaped = x.reshape(B, H, L, d // 2, 2)
    a = x_reshaped[..., 0]
    b = x_reshaped[..., 1]
    angles = positions[:, None] * frequencies[None, :]
    cos_angles = torch.cos(angles)
    sin_angles = torch.sin(angles)
    a_new = a * cos_angles - b * sin_angles
    b_new = a * sin_angles + b * cos_angles
    return torch.stack([a_new, b_new], dim=-1).reshape(B, H, L, d)


def main():
    torch.manual_seed(42)
    dtype = torch.float64
    # 每个头 8 个分量，对应 4 组。显式给出频率以专注配对和广播。
    frequencies = torch.tensor([1., 0.1, 0.01, 0.001], dtype=dtype)
    positions = torch.tensor([0, 1, 2])
    x = torch.randn(2, 4, 3, 8, dtype=dtype)
    original = x.clone()
    rotated = apply_rope(x, positions, frequencies)
    assert rotated.shape == x.shape
    assert torch.equal(x, original)
    assert torch.allclose(rotated[:, :, 0], x[:, :, 0]), "位置 0 的角度均为 0。"
    assert torch.allclose(rotated.norm(dim=-1), x.norm(dim=-1)), "旋转应保持每个向量的长度。"

    # 用逐位置、逐二维组的旋转矩阵作为独立参考。
    reference = torch.empty_like(x)
    for pos in range(3):
        for pair in range(4):
            angle = positions[pos] * frequencies[pair]
            c, s = angle.cos(), angle.sin()
            matrix = torch.stack([torch.stack([c, -s]), torch.stack([s, c])])
            reference[:, :, pos, 2*pair:2*pair+2] = x[:, :, pos, 2*pair:2*pair+2] @ matrix.T
    assert torch.allclose(rotated, reference, atol=1e-10)
    print("输入/输出 shape：", tuple(x.shape), tuple(rotated.shape))
    print("位置 2 的四组旋转角度：", (2 * frequencies).tolist())
    print("位置 0 不变、每组旋转数值与向量长度检查通过。")

    # 固定内容，Q/K 的位置共同平移 5，所有配对位置的点积应不变。
    q = torch.randn(1, 4, 2, 8, dtype=dtype)
    k = torch.randn(1, 4, 3, 8, dtype=dtype)
    q_positions, k_positions = torch.tensor([2, 3]), torch.tensor([0, 1, 2])
    scores = apply_rope(q, q_positions, frequencies) @ apply_rope(k, k_positions, frequencies).transpose(-2, -1)
    shifted = apply_rope(q, q_positions + 5, frequencies) @ apply_rope(k, k_positions + 5, frequencies).transpose(-2, -1)
    assert scores.shape == (1, 4, 2, 3)
    error = (scores - shifted).abs().max().item()
    assert torch.allclose(scores, shifted, atol=1e-10)
    print(f"共同平移位置后，点积最大差：{error:.3g}")

    # 一个 decode 位置的编号仍是全局位置 6，不能在函数内部从 0 重新编号。
    single = apply_rope(x[:, :, :1], torch.tensor([6]), frequencies)
    assert torch.allclose(single, apply_rope(x, torch.tensor([6, 7, 8]), frequencies)[:, :, :1])
    assert apply_rope(x[:, :2], positions, frequencies).shape == (2, 2, 3, 8)
    print("单位置输入与不同头数检查通过！")


if __name__ == "__main__":
    main()
