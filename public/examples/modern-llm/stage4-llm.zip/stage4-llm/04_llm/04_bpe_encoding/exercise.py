"""阶段四第四课：用训练好的 BPE 规则切分新单词。

运行：python3 04_llm/04_bpe_encoding/exercise.py
本课输入单个单词，从字符开始，假设字符都在基础词表中。
只返回 token 字符串列表，暂不转换为 ID，不处理跨单词切分。
"""

import importlib.util
from pathlib import Path


path = Path(__file__).resolve().parents[1] / "01_bpe_merge" / "exercise.py"
spec = importlib.util.spec_from_file_location("bpe_merge", path)
module = importlib.util.module_from_spec(spec)
spec.loader.exec_module(module)
merge_pair = module.merge_pair


def encode_word(word: str, merges: list[tuple[str, str]]) -> list[str]:
    """应用按学习顺序排列的规则，返回新单词的 token 列表。

    本练习的 merges 来自前面的字符级训练过程：每条规则的组成
    token 都是基础字符，或者由更早规则产生的 token。
    本课例子没有不同合并路径产生同一字符串的歧义。
    不重新统计频次，不修改 merges。
    """
    # TODO 1：把 word 切分为字符列表。
    # TODO 2：按 merges 的顺序调用 merge_pair，每次用返回值更新 tokens。
    # TODO 3：返回最终的 tokens。
    tokens = list(word)
    for pair in merges:
        tokens = merge_pair(tokens, pair)
    return tokens


def main():
    merges = [("p", "u"), ("pu", "n")]
    original = merges.copy()
    cases = [
        ("pung", ["pun", "g"]),
        ("pug", ["pu", "g"]),
        ("pun", ["pun"]),
        ("hug", ["h", "u", "g"]),
        ("pupu", ["pu", "pu"]),
        ("p", ["p"]),
        ("", []),
    ]
    for word, expected in cases:
        tokens = encode_word(word, merges)
        print(f"{word!r} → {tokens}")
        assert tokens == expected, f"期望 {expected}，实际 {tokens}"
        assert "".join(tokens) == word, "切分不能丢失或改变字符。"
    assert merges == original, "编码不应改变学好的规则。"
    assert encode_word("pung", []) == ["p", "u", "n", "g"]

    # 同一个输入，不同规则优先级可以产生不同切分。
    assert encode_word("abc", [("a", "b"), ("b", "c")]) == ["ab", "c"]
    assert encode_word("abc", [("b", "c"), ("a", "b")]) == ["a", "bc"]
    print("检查通过！")


if __name__ == "__main__":
    main()
