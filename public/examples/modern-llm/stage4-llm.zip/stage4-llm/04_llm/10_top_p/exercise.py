"""阶段四：top-p 按累计概率选择候选集合。

运行：.venv/bin/python 04_llm/10_top_p/exercise.py
温度固定为 1；保留累计概率首次达到或超过 p 的最短排序前缀。
"""

import importlib.util
from pathlib import Path

import torch

path = Path(__file__).resolve().parents[1] / "07_sampling" / "exercise.py"
spec = importlib.util.spec_from_file_location("sampling", path)
module = importlib.util.module_from_spec(spec)
spec.loader.exec_module(module)
choose_sample = module.choose_sample


def top_p_probs(logits: torch.Tensor, p: float) -> torch.Tensor:
    """有限 logits [B,V] → probabilities [B,V]，不修改输入。

    要求 0 < p <= 1，否则抛出 ValueError。
    p=1 时直接返回完整 softmax，避免浮点累计误差导致末尾被排除。
    并列时接受排序给出的顺序，不要求相同分数一起保留。
    """
    # TODO 1：检查 p 的范围，计算 probabilities = softmax(logits, dim=-1)。
    #         若 p == 1，直接返回 probabilities。
    # TODO 2：按概率降序排序，得到 sorted_probs、indices，均为 [B,V]。
    #         使用 torch.sort(probabilities, dim=-1, descending=True)。
    # TODO 3：沿词表维 cumsum，得到累计概率 cumulative [B,V]。
    # TODO 4：构造 before [B,V]，表示不包含当前项的累计概率。
    #         第一列为 0，后面各列来自 cumulative 的前 V-1 列。
    #         提示：zeros_like 后赋值 before[:, 1:] = cumulative[:, :-1]。
    # TODO 5：keep = before < p；将 sorted_probs 中不保留的项设为 0，
    #         再除以每行保留概率的总和（sum(dim=-1, keepdim=True)）。
    # TODO 6：创建与 probabilities 同 shape 的全零 Tensor，
    #         用 scatter_ 和 indices 将归一化后的排序概率写回原词表位置并返回。
    if not (0 < p <= 1):
        raise ValueError("p 必须在 (0, 1] 范围内。")
    probabilities = torch.softmax(logits, dim=-1)
    if p == 1.0:
        return probabilities
    sorted_probs, indices = torch.sort(probabilities, dim=-1, descending=True)
    cumulative = torch.cumsum(sorted_probs, dim=-1)
    before = torch.zeros_like(cumulative)
    before[:, 1:] = cumulative[:, :-1]
    keep = before < p
    sorted_probs[~keep] = 0
    normalized = sorted_probs / torch.sum(sorted_probs, dim=-1, keepdim=True)
    result = torch.zeros_like(probabilities)
    result.scatter_(dim=1, index=indices, src=normalized)
    return result


def main():
    torch.manual_seed(42)
    torch.set_num_threads(1)
    # 刻意打乱词表中的概率大小，检查排序后能否恢复原 token ID。
    base = torch.tensor([[0.07, 0.50, 0.03, 0.15, 0.25]], dtype=torch.float64)
    logits = base.log()
    original = logits.clone()
    probs = top_p_probs(logits, 0.8)
    expected = torch.tensor([[0., 0.50 / 0.90, 0., 0.15 / 0.90, 0.25 / 0.90]],
                            dtype=torch.float64)
    assert probs.shape == (1, 5)
    assert torch.allclose(probs, expected)
    print("原词表顺序下的概率：", base.tolist())
    print("p=0.8 过滤后的概率：", probs.tolist())
    samples = choose_sample(probs.repeat(10_000, 1))
    counts = torch.bincount(samples.flatten(), minlength=5)
    assert counts[0].item() == counts[2].item() == 0
    print("各 token ID 的采样次数：", counts.tolist())

    batch = torch.tensor([[0.95, 0.03, 0.02], [0.35, 0.33, 0.32]], dtype=torch.float64)
    filtered = top_p_probs(batch.log(), 0.9)
    assert torch.allclose(filtered[0], torch.tensor([1., 0., 0.], dtype=torch.float64))
    assert torch.allclose(filtered[1], batch[1])
    print("两行在 p=0.9 时保留的候选数：", (filtered > 0).sum(dim=-1).tolist())

    # 等概率使累计 0.5 能精确表示，检查恰好达到阈值时不多保留一项。
    equal = top_p_probs(torch.zeros(1, 4, dtype=torch.float64), 0.5)
    assert (equal > 0).sum().item() == 2
    assert torch.allclose(equal[equal > 0], torch.tensor([0.5, 0.5], dtype=torch.float64))
    assert torch.allclose(top_p_probs(logits, 1.0), base)
    tiny = top_p_probs(logits, 0.01)
    assert torch.equal(tiny, torch.tensor([[0., 1., 0., 0., 0.]], dtype=torch.float64))
    assert torch.equal(logits, original)
    for invalid in [0.0, -0.1, 1.1]:
        try:
            top_p_probs(logits, invalid)
        except ValueError:
            pass
        else:
            raise AssertionError("无效 p 应抛出 ValueError。")
    print("检查通过！")


if __name__ == "__main__":
    main()
