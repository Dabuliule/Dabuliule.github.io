"""CPU 原理实验，不是 FlashAttention GPU 内核，也不是完整 MoE 训练系统。"""
import math
import torch
from torch import nn


def tiled_causal_attention(q, k, v, block_size=2):
    """单头 [L,d]，逐行处理、分块读取 KV，不创建完整 [L,L] 矩阵。

    在线 softmax 保存最大值 m、指数和 denominator、加权和 numerator。
    本函数仅供前向演示，不提供优化的反向或 GPU 加速。
    """
    outputs = []
    for row in range(q.shape[0]):
        m = q.new_tensor(-torch.inf)
        denominator = q.new_zeros(())
        numerator = torch.zeros_like(v[0])
        for start in range(0, row + 1, block_size):
            stop = min(start + block_size, row + 1)
            scores = q[row] @ k[start:stop].T / math.sqrt(q.shape[-1])
            new_m = torch.maximum(m, scores.max())
            correction = torch.exp(m - new_m)
            probabilities = torch.exp(scores - new_m)
            numerator = numerator * correction + probabilities @ v[start:stop]
            denominator = denominator * correction + probabilities.sum()
            m = new_m
        outputs.append(numerator / denominator)
    return torch.stack(outputs)


class Top1MoE(nn.Module):
    """每个 token 只执行一个专家，输出乘以该专家的路由概率。

    无容量限制、丢弃或负载均衡损失，不用于实际大模型训练。
    """
    def __init__(self, width=4, experts=3):
        super().__init__()
        self.router = nn.Linear(width, experts, bias=False)
        self.experts = nn.ModuleList([nn.Sequential(nn.Linear(width, 8), nn.ReLU(), nn.Linear(8, width))
                                      for _ in range(experts)])

    def forward(self, x):
        flat = x.reshape(-1, x.shape[-1])
        probabilities = self.router(flat).softmax(-1)  # [B*L,E]
        selected = probabilities.argmax(-1)           # [B*L]
        output = torch.zeros_like(flat)
        for index, expert in enumerate(self.experts):
            mask = selected == index
            if mask.any():
                output[mask] = expert(flat[mask]) * probabilities[mask, index, None]
        return output.reshape_as(x), selected


def main():
    torch.manual_seed(42)
    q, k, v = [torch.randn(7, 4, dtype=torch.float64) for _ in range(3)]
    scores = q @ k.T / 2
    reference = scores.masked_fill(torch.ones(7, 7, dtype=torch.bool).triu(1), -torch.inf).softmax(-1) @ v
    for block_size in [1, 2, 3, 8]:
        actual = tiled_causal_attention(q, k, v, block_size)
        assert torch.allclose(actual, reference, atol=1e-10)
    print("分块在线 softmax 与完整因果注意力一致；未测试 GPU 加速。")
    moe = Top1MoE()
    with torch.no_grad():
        moe.router.weight.copy_(torch.tensor([[1.,0.,0.,0.], [0.,1.,0.,0.], [0.,0.,1.,0.]]))
    x = torch.tensor([[[3.,0.,0.,1.], [0.,3.,0.,1.], [0.,0.,3.,1.], [2.,0.,0.,1.]]])
    calls = [0, 0, 0]
    def hook(index):
        def count(module, args, output):
            calls[index] += args[0].shape[0]
        return count
    handles = [expert.register_forward_hook(hook(i)) for i, expert in enumerate(moe.experts)]
    output, selected = moe(x)
    for handle in handles:
        handle.remove()
    assert selected.tolist() == [0, 1, 2, 0] and calls == [2, 1, 1]
    flat = x.reshape(-1, 4)
    probabilities = moe.router(flat).softmax(-1)
    expected = torch.stack([moe.experts[e](flat[i]) * probabilities[i,e]
                            for i,e in enumerate(selected.tolist())]).reshape_as(x)
    assert torch.allclose(output, expected)
    output.square().mean().backward()
    assert moe.router.weight.grad is not None and moe.router.weight.grad.abs().sum() > 0
    print(f"MoE 路由：{selected.tolist()}，每个专家实际处理 token 数：{calls}（总计 4，不是 12）。")


if __name__ == "__main__":
    main()
