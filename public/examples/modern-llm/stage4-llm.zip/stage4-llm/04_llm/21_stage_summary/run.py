"""阶段四收尾实验。运行：.venv/bin/python 04_llm/21_stage_summary/run.py"""
from pathlib import Path
import importlib.util
import torch
import torch.nn.functional as F
from model import LanguageModel, generate
from efficiency import main as check_efficiency


def check_model():
    model = LanguageModel(8).eval()
    prefix = torch.tensor([[1,2,3], [2,3,4]])
    _, cache = model(prefix)
    for new_ids in [torch.tensor([[4],[5]]), torch.tensor([[5,6],[6,7]])]:
        incremental, cache = model(new_ids, cache)
        prefix = torch.cat([prefix, new_ids], 1)
        full, full_cache = model(prefix)
        assert torch.allclose(incremental, full[:, -new_ids.shape[1]:], atol=1e-6, rtol=1e-5)
        for (k,v), (rk,rv) in zip(cache, full_cache):
            assert k.shape == v.shape == (2,2,prefix.shape[1],8)
            assert torch.allclose(k,rk,atol=1e-6,rtol=1e-5)
            assert torch.allclose(v,rv,atol=1e-6,rtol=1e-5)
    elements = sum(k.numel() + v.numel() for k,v in cache)
    assert elements == 2 * 2 * 2 * 2 * 6 * 8
    print(f"GQA 缓存等价性通过；缓存 {elements} 个元素，同配置 MHA 为 {elements*2}。")
    # 第一层对照独立按头读取 KV，避免两条路径共享相同分组错误。
    block = model.layers[0]
    x = model.embedding(prefix)
    norm = block.attention_norm(x)
    q = block.split_heads(block.query(norm))
    from model import apply_rope
    q = apply_rope(q, torch.arange(6), block.frequencies)
    actual, (k,v) = block(x)
    mask = torch.ones(6,6,dtype=torch.bool).triu(1)
    heads = []
    for h in range(4):
        weights = (q[:,h] @ k[:,h//2].transpose(-2,-1) / 8**0.5).masked_fill(mask,-torch.inf).softmax(-1)
        heads.append(weights @ v[:,h//2])
    joined = torch.stack(heads,dim=1).transpose(1,2).reshape(2,6,32)
    reference = x + block.attention_output(joined)
    reference = reference + block.ffn(block.ffn_norm(reference))
    assert torch.allclose(actual,reference,atol=1e-6)
    # 未来位置变化不影响旧位置。
    changed = prefix.clone()
    changed[:,-1] = (changed[:,-1]+1)%8
    assert torch.allclose(model(prefix)[0][:,:-1], model(changed)[0][:,:-1],atol=1e-6)
    model.zero_grad()
    logits,_ = model(prefix[:,:-1])
    F.cross_entropy(logits.reshape(-1,8),prefix[:,1:].reshape(-1)).backward()
    assert all(p.grad is not None and torch.isfinite(p.grad).all() for p in model.parameters())

    # 确定性控制输出，逐项测试生成停止条件。
    with torch.no_grad():
        model.output.weight.zero_()
        model.output.bias.zero_()
        model.output.bias[0] = 100
    prompt = torch.tensor([[1,2]])
    ids,reason = generate(model,prompt,0,7)
    assert reason == "eos" and ids.tolist() == [[1,2,0]]
    ids,reason = generate(model,prompt,0,7,max_new_tokens=0)
    assert reason == "max_new_tokens" and torch.equal(ids,prompt)
    with torch.no_grad():
        model.output.bias[0] = 0
        model.output.bias[1] = 10
        model.output.bias[7] = 100  # pad 分数最高，也不能被选出。
    ids,reason = generate(model,prompt,0,7,max_new_tokens=2)
    assert reason == "max_new_tokens" and ids.tolist() == [[1,2,1,1]]
    model.context_limit = 3
    ids,reason = generate(model,prompt,0,7)
    assert reason == "context_limit" and ids.shape == (1,3)
    try:
        model(torch.ones(1,4,dtype=torch.long))
    except ValueError:
        pass
    else:
        raise AssertionError("超过上下文限制应该拒绝。")
    print("GQA 头映射、因果性、梯度、EOS/PAD/长度停止检查通过。")


def text_demo():
    root = Path(__file__).resolve().parents[2]
    source = root / "experiments/text_completion"
    spec = importlib.util.spec_from_file_location("text_data",source / "train.py")
    data = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(data)
    sentences = [s.strip() for s in (source / "corpus.txt").read_text().splitlines() if s.strip()]
    vocab = ["<eos>"] + sorted(set("".join(sentences))) + ["<pad>"]
    mapping = {s:i for i,s in enumerate(vocab)}
    inputs,labels = data.make_data(sentences,mapping)
    torch.manual_seed(42)
    model = LanguageModel(len(vocab))
    optimizer = torch.optim.AdamW(model.parameters(),lr=0.005)
    def loss():
        logits,_ = model(inputs)
        return F.cross_entropy(logits.reshape(-1,len(vocab)), labels.reshape(-1),ignore_index=-100)
    initial = loss().item()
    for _ in range(200):
        optimizer.zero_grad()
        current = loss()
        current.backward()
        optimizer.step()
    final = loss().item()
    assert final < initial
    print(f"\n小语料训练 loss：{initial:.4f} → {final:.4f}（训练演示，不是泛化评测）")
    for temperature in [0.,1.2]:
        torch.manual_seed(10)
        prompt = torch.tensor([[mapping["我"]]])
        ids,reason = generate(model,prompt,mapping["<eos>"],mapping["<pad>"],temperature=temperature)
        text = "".join(vocab[i] for i in ids[0].tolist() if i != mapping["<eos>"])
        print(f"T={temperature}，top-p=0.9：{text}；停止原因={reason}")


if __name__ == "__main__":
    torch.manual_seed(42)
    torch.set_num_threads(1)
    check_model()
    check_efficiency()
    text_demo()
    print("\n阶段四收尾实验全部通过。")
