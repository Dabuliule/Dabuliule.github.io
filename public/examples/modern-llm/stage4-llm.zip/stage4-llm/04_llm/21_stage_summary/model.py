"""阶段四整合模型：RoPE + RMSNorm + SwiGLU + GQA + KV Cache。

教学用 CPU 实现：显式扩展 KV，不是高性能 GQA/FlashAttention 内核。
"""
import importlib.util
from pathlib import Path
import torch
from torch import nn

STAGE = Path(__file__).resolve().parents[1]


def load(name, relative):
    spec = importlib.util.spec_from_file_location(name, STAGE / relative / "exercise.py")
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


modern = load("modern", "20_modern_block")
apply_rope = modern.rope.apply_rope
top_p_probs = load("nucleus", "10_top_p").top_p_probs


class GQABlock(modern.ModernBlock):
    def __init__(self):
        super().__init__()
        self.num_kv_heads = 2
        self.key = nn.Linear(32, 16)
        self.value = nn.Linear(32, 16)

    def forward(self, states, cache=None):
        B, L, _ = states.shape
        past = 0 if cache is None else cache[0].shape[2]
        x = self.attention_norm(states)
        q = self.split_heads(self.query(x))  # [B,4,L,8]
        k = self.key(x).reshape(B, L, 2, 8).transpose(1, 2)
        v = self.value(x).reshape(B, L, 2, 8).transpose(1, 2)
        positions = torch.arange(past, past + L, device=x.device)
        q, k = apply_rope(q, positions, self.frequencies), apply_rope(k, positions, self.frequencies)
        if cache is not None:
            k = torch.cat([cache[0], k], dim=2)
            v = torch.cat([cache[1], v], dim=2)
        new_cache = (k, v)  # 只保存两个 KV 头，K 已旋转。
        expanded_k = k.repeat_interleave(2, dim=1)
        expanded_v = v.repeat_interleave(2, dim=1)
        scores = q @ expanded_k.transpose(-2, -1) / 8 ** 0.5
        future = torch.ones(L, k.shape[2], dtype=torch.bool, device=x.device).triu(past + 1)
        attention = scores.masked_fill(future, -torch.inf).softmax(-1) @ expanded_v
        joined = attention.transpose(1, 2).reshape(B, L, 32)
        h = states + self.attention_output(joined)
        return h + self.ffn(self.ffn_norm(h)), new_cache


class LanguageModel(nn.Module):
    def __init__(self, vocab_size, context_limit=64):
        super().__init__()
        self.context_limit = context_limit  # 实验限制，不是 RoPE 的质量外推保证。
        self.embedding = nn.Embedding(vocab_size, 32)
        self.layers = nn.ModuleList([GQABlock() for _ in range(2)])
        self.final_norm = modern.RMSNorm(32)
        self.output = nn.Linear(32, vocab_size)

    def forward(self, ids, caches=None):
        past = 0 if caches is None else caches[0][0].shape[2]
        if ids.shape[1] == 0 or past + ids.shape[1] > self.context_limit:
            raise ValueError("输入不能为空，历史与输入总长度不能超过上下文限制。")
        x = self.embedding(ids)
        updated = []
        for i, layer in enumerate(self.layers):
            x, cache = layer(x, None if caches is None else caches[i])
            updated.append(cache)
        return self.output(self.final_norm(x)), updated


@torch.no_grad()
def generate(model, prompt_ids, eos_id, pad_id, max_new_tokens=16, temperature=0., top_p=0.9):
    """单序列生成；T=0 走贪心，其余走 temperature + top-p。

    返回 (完整 ID Tensor, 停止原因)。达到总上下文长度即停止，不滑动截断。
    """
    if temperature < 0 or not 0 < top_p <= 1 or max_new_tokens < 0:
        raise ValueError("生成参数非法。")
    if prompt_ids.ndim != 2 or prompt_ids.shape[0] != 1 or prompt_ids.shape[1] == 0:
        raise ValueError("prompt 必须是非空的 [1,L]。")
    if prompt_ids.shape[1] > model.context_limit:
        raise ValueError("prompt 超过上下文限制。")
    model.eval()
    result = prompt_ids.clone()
    if max_new_tokens == 0:
        return result, "max_new_tokens"
    if result.shape[1] == model.context_limit:
        return result, "context_limit"
    logits, cache = model(result)  # prefill 给出第一个新 token 的分布。
    for step in range(max_new_tokens):
        scores = logits[:, -1, :].clone()
        scores[:, pad_id] = -torch.inf
        next_id = scores.argmax(-1, keepdim=True) if temperature == 0 else torch.multinomial(
            top_p_probs(scores / temperature, top_p), 1)
        result = torch.cat([result, next_id], dim=1)
        if next_id.item() == eos_id:
            return result, "eos"
        if result.shape[1] == model.context_limit:
            return result, "context_limit"
        if step + 1 < max_new_tokens:
            logits, cache = model(next_id, cache)
    return result, "max_new_tokens"
