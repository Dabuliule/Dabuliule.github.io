"""阶段四：4 个 Q 头共享 2 个 KV 头，输出仍是 4 个头。

运行：.venv/bin/python 04_llm/14_gqa/exercise.py
只计算单个 decode 位置：所有 K/V 位置均可见，无 padding。
显式重复 KV 便于理解，不是高性能实现；不修改已有模型结构。
"""

import math

import torch


def grouped_attention(Q, K, V):
    """Q [B,Hq,1,d]，K/V [B,Hkv,L,d] → output [B,Hq,1,d]。

    假设 Hq 是 Hkv 的整数倍；K/V 包括历史与当前位置。
    返回 (output, weights)，weights [B,Hq,1,L]。
    """
    # TODO 1：计算每组 Q 头数 groups = Hq // Hkv。
    # TODO 2：用 repeat_interleave(groups, dim=1) 扩展 K、V。
    # TODO 3：Q @ K_expanded.transpose(-2, -1)，除以 sqrt(d)。
    # TODO 4：沿最后一维 softmax 得到 weights，再加权 V_expanded。
    # TODO 5：返回 output, weights。
    groups = Q.shape[1] // K.shape[1]
    K_expanded = K.repeat_interleave(groups, dim=1)
    V_expanded = V.repeat_interleave(groups, dim=1)
    scores = Q @ K_expanded.transpose(-2, -1) / math.sqrt(Q.shape[-1])
    weights = scores.softmax(dim=-1)
    output = weights @ V_expanded
    return output, weights


def main():
    # 同一组内的 Q 刻意不同，观察共享 KV 是否必然产生相同输出。
    Q = torch.tensor([[[[2., 0.]], [[0., 2.]], [[1., 0.]], [[0., 1.]]]])
    K = torch.tensor([[[[1., 0.], [0., 1.], [1., 1.]],
                       [[2., 0.], [0., 2.], [1., 1.]]]])
    V = torch.tensor([[[[10., 0.], [0., 10.], [5., 5.]],
                       [[20., 0.], [0., 20.], [2., 2.]]]])
    original_k, original_v = K.clone(), V.clone()
    output, weights = grouped_attention(Q, K, V)
    assert output.shape == (1, 4, 1, 2)
    assert weights.shape == (1, 4, 1, 3)
    assert torch.allclose(weights.sum(dim=-1), torch.ones(1, 4, 1))
    # 按每个 Q 头独立索引原始 KV，核对映射，避免 repeat 与 repeat_interleave 混淆。
    for head in range(4):
        kv_head = head // 2
        scores = Q[:, head] @ K[:, kv_head].transpose(-2, -1) / math.sqrt(2)
        reference_weights = scores.softmax(dim=-1)
        reference_output = reference_weights @ V[:, kv_head]
        assert torch.allclose(weights[:, head], reference_weights)
        assert torch.allclose(output[:, head], reference_output)
        print(f"Q{head} 使用 KV{kv_head}：权重 {weights[0, head, 0].tolist()}，"
              f"输出 {output[0, head, 0].tolist()}")
    assert not torch.allclose(output[:, 0], output[:, 1])
    assert torch.equal(K, original_k) and torch.equal(V, original_v)
    print("\n原始 K/V shape：", tuple(K.shape))
    print("注意力输出 shape：", tuple(output.shape))
    joined = output.transpose(1, 2).reshape(1, 1, 8)
    print("拼接四个头后：", tuple(joined.shape))
    # 同一个函数也应支持所有 Q 头共享一组 KV，以及每头独享 KV。
    for kv_heads in [1, 4]:
        torch.manual_seed(kv_heads)
        q = torch.randn(2, 4, 1, 3)
        k, v = torch.randn(2, kv_heads, 5, 3), torch.randn(2, kv_heads, 5, 3)
        out, attn = grouped_attention(q, k, v)
        assert out.shape == (2, 4, 1, 3) and attn.shape == (2, 4, 1, 5)
        for head in range(4):
            index = head // (4 // kv_heads)
            expected = (q[:, head] @ k[:, index].transpose(-2, -1) / math.sqrt(3)).softmax(-1) @ v[:, index]
            assert torch.allclose(out[:, head], expected, atol=1e-6)
    print("检查通过！输出头数由 Q 头数决定。")


if __name__ == "__main__":
    main()
