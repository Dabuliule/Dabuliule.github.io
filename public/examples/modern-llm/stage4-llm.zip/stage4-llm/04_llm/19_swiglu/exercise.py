"""阶段四：SwiGLU 用一条分支调节另一条分支的特征。

运行：.venv/bin/python 04_llm/19_swiglu/exercise.py
不训练模型；先用可控权重观察门控，再检查通用 shape 与梯度。
"""

import torch
from torch import nn
import torch.nn.functional as F


class SwiGLU(nn.Module):
    def __init__(self, hidden_size, intermediate_size):
        super().__init__()
        # TODO 1：创建三个无 bias 的 nn.Linear。
        # gate_proj、up_proj：D → F；down_proj：F → D。
        self.gate_proj = nn.Linear(hidden_size, intermediate_size, bias=False)
        self.up_proj = nn.Linear(hidden_size, intermediate_size, bias=False)
        self.down_proj = nn.Linear(intermediate_size, hidden_size, bias=False)

    def forward(self, x):
        """x [B,L,D] → 输出 [B,L,D]；中间分支均为 [B,L,F]。"""
        # TODO 2：gate = F.silu(self.gate_proj(x))。
        # TODO 3：value = self.up_proj(x)，不要给这条分支加激活。
        # TODO 4：gate 与 value 对应元素相乘，再交给 down_proj。
        gate = F.silu(self.gate_proj(x))
        value = self.up_proj(x)
        return self.down_proj(gate * value)


def main():
    # 先用 D=2、F=1 隔离门控的作用，不代表实际模型的扩维比例。
    model = SwiGLU(2, 1)
    assert all(isinstance(layer, nn.Linear) for layer in
               [model.gate_proj, model.up_proj, model.down_proj]), "请完成三个投影层。"
    assert model.gate_proj.bias is model.up_proj.bias is model.down_proj.bias is None
    with torch.no_grad():
        model.up_proj.weight.copy_(torch.tensor([[1., 0.]]))  # value 只读第一个分量。
        model.gate_proj.weight.copy_(torch.tensor([[0., 1.]]))  # gate 只读第二个分量。
        model.down_proj.weight.copy_(torch.tensor([[1.], [2.]]))
    x = torch.tensor([[[3., -2.], [3., 0.], [3., 2.]]])  # [1,3,2]
    y = model(x)
    values = model.up_proj(x)
    gates = F.silu(model.gate_proj(x))
    assert values.shape == gates.shape == (1, 3, 1)
    assert y.shape == (1, 3, 2)
    assert torch.equal(values, torch.full_like(values, 3.))
    expected_hidden = torch.tensor([-6. / (1. + torch.exp(torch.tensor(2.)).item()),
                                    0., 6. / (1. + torch.exp(torch.tensor(-2.)).item())])
    expected = torch.stack([expected_hidden, 2 * expected_hidden], dim=-1).unsqueeze(0)
    assert torch.allclose(y, expected, atol=1e-6)
    for pos in range(3):
        print(f"输入 {x[0, pos].tolist()}：value={values[0, pos].item():.3f}，"
              f"gate={gates[0, pos].item():.3f}，输出={y[0, pos].detach().tolist()}")
    print("特征值始终为 3，但门控随输入变化；门控可以为负数或大于 1。")

    torch.manual_seed(42)
    larger = SwiGLU(8, 16)
    assert larger.gate_proj.weight.shape == larger.up_proj.weight.shape == (16, 8)
    assert larger.down_proj.weight.shape == (8, 16)
    probe = torch.randn(2, 3, 8, requires_grad=True)
    output = larger(probe)
    assert output.shape == (2, 3, 8)
    # 按线性代数展开核对；PyTorch Linear 的 weight 存储为 [out,in]。
    g = probe @ larger.gate_proj.weight.T
    u = probe @ larger.up_proj.weight.T
    reference = ((g * torch.sigmoid(g)) * u) @ larger.down_proj.weight.T
    assert torch.allclose(output, reference, atol=1e-6)
    output.square().mean().backward()
    assert probe.grad is not None and torch.isfinite(probe.grad).all()
    for name, parameter in larger.named_parameters():
        assert parameter.grad is not None and torch.isfinite(parameter.grad).all(), name
    print("shape、前向数值及三个投影层的梯度检查通过！")


if __name__ == "__main__":
    main()
