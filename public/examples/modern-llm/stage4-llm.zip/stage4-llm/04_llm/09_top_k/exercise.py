"""阶段四：top-k 只让前 k 名参加采样。

运行：.venv/bin/python 04_llm/09_top_k/exercise.py
本课固定温度为 1，只学习候选过滤；后续再组合生成策略。
"""

import importlib.util
from pathlib import Path

import torch


path = Path(__file__).resolve().parents[1] / "07_sampling" / "exercise.py"
spec = importlib.util.spec_from_file_location("sampling", path)
module = importlib.util.module_from_spec(spec)
spec.loader.exec_module(module)
choose_sample = module.choose_sample


def top_k_probs(logits: torch.Tensor, k: int) -> torch.Tensor:
    """有限 logits [B,V] → probabilities [B,V]，仅保留每行最高的 k 项。

    假设 k 为整数；要求 1 <= k <= V，否则抛出 ValueError。
    不修改 logits。并列时接受 torch.topk 选出的任意 k 项，不要求稳定顺序。
    """
    # TODO 1：检查 k 的合法范围。
    # TODO 2：torch.topk(logits, k, dim=-1)，得到 values、indices，均为 [B,k]。
    # TODO 3：torch.full_like(logits, float("-inf"))，创建 filtered [B,V]。
    # TODO 4：filtered.scatter_(dim=1, index=indices, src=values)，写回保留分数。
    # TODO 5：沿最后一维 softmax，返回 [B,V] 概率。
    if not (1 <= k <= logits.size(-1)):
        raise ValueError("k 必须在 [1, V] 范围内。")
    values, indices = torch.topk(logits, k, dim=-1)
    filtered = torch.full_like(logits, float("-inf"))
    filtered.scatter_(dim=1, index=indices, src=values)
    return torch.softmax(filtered, dim=-1)


def main():
    torch.manual_seed(42)
    torch.set_num_threads(1)
    vocab = ["茶", "水", "咖啡", "石头", "飞机"]
    original_probs = torch.tensor([[0.50, 0.30, 0.15, 0.04, 0.01]])
    # 这些 logits 的 softmax 就是上面的概率，方便手工核对。
    logits = original_probs.log()
    original = logits.clone()
    probs = top_k_probs(logits, k=3)
    expected = torch.tensor([[0.50 / 0.95, 0.30 / 0.95, 0.15 / 0.95, 0.0, 0.0]])
    assert probs.shape == (1, 5)
    assert torch.allclose(probs, expected, atol=1e-6)
    assert torch.equal(probs[:, 3:], torch.zeros(1, 2))
    samples = choose_sample(probs.repeat(10_000, 1))
    counts = torch.bincount(samples.flatten(), minlength=5)
    assert counts[3:].sum().item() == 0
    print("k=3：")
    for i, token in enumerate(vocab):
        print(f"{token}：过滤前 {original_probs[0, i]:.1%}，"
              f"过滤后 {probs[0, i]:.1%}，采样 {counts[i].item()} 次")

    assert torch.allclose(top_k_probs(logits, 5), original_probs)
    assert torch.equal(top_k_probs(logits, 1), torch.tensor([[1., 0., 0., 0., 0.]]))
    # 最高分位于不同索引，检查没有把 top-k 排名误当成原词表 ID。
    batch = torch.tensor([[0., 3., 1., 2.], [4., 0., 3., 1.]])
    batch_probs = top_k_probs(batch, 2)
    assert batch_probs.shape == (2, 4)
    assert torch.equal(batch_probs > 0, torch.tensor([[False, True, False, True],
                                                        [True, False, True, False]]))
    assert torch.allclose(batch_probs.sum(dim=-1), torch.ones(2))
    # 全部分数并列时仍只保留 k 项，不用阈值比较扩大候选集合。
    tied = top_k_probs(torch.zeros(1, 4), 2)
    assert (tied > 0).sum().item() == 2
    assert torch.allclose(tied[tied > 0], torch.tensor([0.5, 0.5]))
    assert torch.equal(logits, original)
    for invalid in [0, -1, 6]:
        try:
            top_k_probs(logits, invalid)
        except ValueError:
            pass
        else:
            raise AssertionError("无效 k 应抛出 ValueError。")
    print("检查通过！")


if __name__ == "__main__":
    main()
