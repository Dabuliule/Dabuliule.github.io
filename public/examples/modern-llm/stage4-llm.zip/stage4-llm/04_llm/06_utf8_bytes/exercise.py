"""阶段四第六课：UTF-8 字节编码与解码。

运行：python3 04_llm/06_utf8_bytes/exercise.py
本课不做 BPE 合并；特意让 256 个基础 token 的 ID 等于字节值。
实际 tokenizer 的 ID 不一定等于字节值。本课不涉及 Tensor。
"""


def encode_bytes(text: str) -> list[int]:
    """有效 Unicode 文本 → UTF-8 字节值列表，每个整数在 0~255。"""
    # TODO 1：用 text.encode("utf-8") 得到 bytes，再转换成整数列表。
    return list(text.encode("utf-8"))

def decode_bytes(ids: list[int]) -> str:
    """先还原整个 bytes，再统一按 UTF-8 解码。

    假设整数在 0~255。如果整个序列不是合法 UTF-8，让解码报错，
    不使用 errors="ignore" 或 errors="replace" 隐藏问题。
    """
    # TODO 2：用 bytes(ids) 还原字节串，再调用 .decode("utf-8")。
    return bytes(ids).decode("utf-8")


def main():
    for text, expected in [
        ("A", [65]),
        ("中", [228, 184, 173]),
        ("A中", [65, 228, 184, 173]),
        ("", []),
    ]:
        ids = encode_bytes(text)
        restored = decode_bytes(ids)
        print(f"{text!r} → {ids} → {restored!r}")
        print(f"Python 字符串长度：{len(text)}；字节数：{len(ids)}")
        assert ids == expected
        assert restored == text

    text = "你好，AI！🙂"
    ids = encode_bytes(text)
    assert all(isinstance(value, int) and 0 <= value <= 255 for value in ids)
    assert decode_bytes(ids) == text
    print(f"混合文本：{text!r} → {ids}")

    # 三个字节合起来表示“中”，但第一个字节无法单独解码成字符。
    try:
        decode_bytes([228])
    except UnicodeDecodeError:
        print("预期现象：[228] 单独解码失败；[228, 184, 173] 可以解码。")
    else:
        raise AssertionError("不完整的 UTF-8 序列应解码失败。")
    print("检查通过！")


if __name__ == "__main__":
    main()

# 思考：有了全部 256 个基础字节 token，是否意味着任意 ID 序列
# 都能解码为合法的 UTF-8 文本？
