"""阶段四第二课：统计 BPE 相邻 token 对的加权频次。

运行：uv run --frozen python 04_llm/02_bpe_pair_counts/exercise.py
只使用 Python 列表、元组和字典，不涉及 Tensor。
每条记录包含当前 token 切分和这个单词在语料中的出现次数。
"""


def count_pairs(
    corpus: list[tuple[list[str], int]],
) -> dict[tuple[str, str], int]:
    """统计各条记录内部的相邻对，不跨记录，不修改输入。

    相邻位置可以重叠：["a", "a", "a"] 中 ("a", "a") 出现两次。
    假设单词频次为正整数，空列表和单 token 列表不贡献相邻对。
    """
    # TODO 1：创建字典，key 是 (左 token, 右 token)，value 是累计频次。
    # TODO 2：遍历每条记录，再遍历该记录所有相邻位置。
    # TODO 3：每遇到一个相邻对，将该记录的单词频次累加到字典中。
    # TODO 4：返回统计结果。
    result = {}
    for tokens, freq in corpus:
        for i in range(len(tokens) - 1):
            pair = (tokens[i], tokens[i + 1])
            result[pair] = result.get(pair, 0) + freq
    return result


def main():
    corpus = [
        (["h", "u", "g"], 10),
        (["p", "u", "g"], 5),
        (["p", "u", "n"], 12),
        (["b", "u", "n"], 4),
    ]
    original = [(tokens.copy(), freq) for tokens, freq in corpus]
    counts = count_pairs(corpus)
    print("初始统计：", counts)
    assert counts == {
        ("h", "u"): 10,
        ("u", "g"): 15,
        ("p", "u"): 17,
        ("u", "n"): 16,
        ("b", "u"): 4,
    }
    assert corpus == original, "统计不能修改输入。"

    after_merge = [
        (["h", "u", "g"], 10),
        (["pu", "g"], 5),
        (["pu", "n"], 12),
        (["b", "u", "n"], 4),
    ]
    updated = count_pairs(after_merge)
    print("合并 p + u 后的统计：", updated)
    assert updated == {
        ("h", "u"): 10,
        ("u", "g"): 10,
        ("pu", "g"): 5,
        ("pu", "n"): 12,
        ("b", "u"): 4,
        ("u", "n"): 4,
    }
    assert count_pairs([(["a", "a", "a"], 3)]) == {("a", "a"): 6}
    assert count_pairs([(["p"], 2), (["u"], 3), ([], 1)]) == {}
    assert count_pairs([]) == {}
    print("检查通过！")


if __name__ == "__main__":
    main()

# 思考：为什么统计 ["a", "a", "a"] 时有两个相邻对，
# 但应用一次 ("a", "a") 合并规则时只能合并一次？
