"""阶段四：用二维旋转理解 RoPE 的相对位置性质。

运行：.venv/bin/python 04_llm/15_rope_rotation/exercise.py
只处理一个二维向量，不是完整 RoPE；无模型、无训练。
"""

import math

import torch


def rotate_pair(vector: torch.Tensor, angle: float) -> torch.Tensor:
    """vector [2] → 旋转后的 [2]；angle 使用弧度。

    逆时针旋转，不修改输入。
    x_new = x*cos(angle) - y*sin(angle)
    y_new = x*sin(angle) + y*cos(angle)
    """
    # TODO 1：取出 x、y；用 math.cos(angle)、math.sin(angle) 算余弦、正弦。
    # TODO 2：按上面公式计算两个新坐标。
    # TODO 3：用 torch.stack([x_new, y_new]) 返回 shape [2]。
    x, y = vector
    cos_angle = math.cos(angle)
    sin_angle = math.sin(angle)
    x_new = x * cos_angle - y * sin_angle
    y_new = x * sin_angle + y * cos_angle
    return torch.stack([x_new, y_new])


def position_score(q, k, q_position, k_position, theta):
    """固定原始 q、k，按各自位置旋转后取点积，返回标量 Tensor []。"""
    # TODO 4：分别以 q_position*theta、k_position*theta 为角度调用 rotate_pair。
    # TODO 5：用 torch.dot 对两个旋转后的向量取点积。
    q_rotated = rotate_pair(q, q_position * theta)
    k_rotated = rotate_pair(k, k_position * theta)
    return torch.dot(q_rotated, k_rotated)


def main():
    vector = torch.tensor([1., 0.], dtype=torch.float64)
    original = vector.clone()
    for degrees, expected in [(0, [1., 0.]), (90, [0., 1.]), (180, [-1., 0.])]:
        rotated = rotate_pair(vector, math.radians(degrees))
        assert rotated.shape == (2,)
        assert torch.allclose(rotated, torch.tensor(expected, dtype=torch.float64), atol=1e-10)
        print(f"[1,0] 旋转 {degrees}° → {rotated.tolist()}")
    assert torch.equal(vector, original)
    # 不仅测试 [1,0]，避免遗漏 y 项或写错正负号。
    other = torch.tensor([3., 4.], dtype=torch.float64)
    rotated = rotate_pair(other, math.pi / 2)
    assert torch.allclose(rotated, torch.tensor([-4., 3.], dtype=torch.float64), atol=1e-10)
    assert torch.allclose(rotated.norm(), other.norm())

    theta = math.pi / 6  # 每前进一个位置，旋转 30°。
    q = k = vector
    scores = []
    for q_pos, k_pos in [(1, 0), (2, 1), (2, 0)]:
        score = position_score(q, k, q_pos, k_pos, theta)
        assert score.shape == torch.Size([])
        scores.append(score)
        print(f"Q 位置 {q_pos}，K 位置 {k_pos}：点积 {score.item():.6f}")
    assert torch.allclose(scores[0], scores[1], atol=1e-10)
    assert torch.allclose(scores[0], torch.tensor(math.sqrt(3) / 2, dtype=torch.float64))
    assert torch.allclose(scores[2], torch.tensor(0.5, dtype=torch.float64))

    # 不同内容向量同样满足共同平移的位置性质。
    q = torch.tensor([1., 2.], dtype=torch.float64)
    k = torch.tensor([3., -1.], dtype=torch.float64)
    before = position_score(q, k, 2, 0, theta)
    after = position_score(q, k, 5, 3, theta)
    assert torch.allclose(before, after, atol=1e-10)
    # 同一个例子绕满一圈再次对齐，说明“距离越远分数越低”不是普遍规律。
    full_circle = position_score(vector, vector, 12, 0, theta)
    assert torch.allclose(full_circle, torch.tensor(1., dtype=torch.float64))
    print(f"相隔 12 个位置（360°），点积回到 {full_circle.item():.6f}。")
    print("检查通过！固定内容时，共同平移位置不改变旋转后的点积。")


if __name__ == "__main__":
    main()
