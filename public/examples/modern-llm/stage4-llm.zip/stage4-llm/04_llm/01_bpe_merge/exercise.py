"""阶段四第一课：应用一次 BPE 合并规则。

运行：uv run --frozen python 04_llm/01_bpe_merge/exercise.py
本课只处理 list[str]，不涉及 Tensor，也不统计或学习合并规则。
"""


def merge_pair(tokens: list[str], pair: tuple[str, str]) -> list[str]:
    """从左到右、不重叠地合并所有匹配 pair 的相邻 token。

    返回一个新列表，不修改输入。匹配的是完整 token，不是 token 内的字符。
    例如：["p", "u", "p", "u"] 配合 ("p", "u") → ["pu", "pu"]。
    新合并出的 token 不在本次扫描中再次参与合并。
    """
    # TODO：实现合并逻辑。
    # 提示 1：用新列表保存结果，用索引 i 从左到右扫描输入。
    # 提示 2：检查相邻对之前，先确保 i + 1 没有越界。
    # 提示 3：匹配成功时消耗两个输入 token，否则只消耗一个。
    result = []
    i = 0
    while i < len(tokens):
        if i + 1 < len(tokens) and (tokens[i], tokens[i + 1]) == pair:
            result.append(tokens[i] + tokens[i + 1])
            i += 2
        else:
            result.append(tokens[i])
            i += 1
    return result


def main():
    cases = [
        (["p", "u", "n", "g"], ("p", "u"), ["pu", "n", "g"]),
        (["p", "u", "p", "u"], ("p", "u"), ["pu", "pu"]),
        (["a", "a", "a"], ("a", "a"), ["aa", "a"]),
        (["pu", "n"], ("u", "n"), ["pu", "n"]),
        (["pu", "n"], ("pu", "n"), ["pun"]),
        (["h", "u", "g"], ("p", "u"), ["h", "u", "g"]),
        (["p"], ("p", "u"), ["p"]),
        ([], ("p", "u"), []),
    ]
    for tokens, pair, expected in cases:
        original = tokens.copy()
        actual = merge_pair(tokens, pair)
        print(f"{tokens}，合并 {pair} → {actual}")
        assert actual == expected, f"期望 {expected}，实际 {actual}"
        assert tokens == original, "不能修改输入列表。"
        assert actual is not tokens, "应返回新列表，即使没有匹配。"
    print("检查通过！")


if __name__ == "__main__":
    main()

# 思考：为什么匹配成功后要前进两个位置，而不是一个？
