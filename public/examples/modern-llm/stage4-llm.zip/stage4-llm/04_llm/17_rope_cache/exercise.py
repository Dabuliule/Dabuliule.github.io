"""RoPE 整合：新 Q/K 旋转后，缓存已旋转的 K 和未旋转的 V。

运行：.venv/bin/python 04_llm/17_rope_cache/exercise.py
复用已有层和 apply_rope；随机初始化，只检查计算，不训练。
"""

import importlib.util
from pathlib import Path

import torch
from torch import nn


ROOT = Path(__file__).resolve().parents[2]


def load(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


base = load("text_model", ROOT / "experiments/text_completion/train.py")
apply_rope = load("rope_pairs", ROOT / "04_llm/16_rope_pairs/exercise.py").apply_rope


class RoPEBlock(base.TransformerBlock):
    def __init__(self):
        super().__init__()
        # 每头 8 维，4 个二维组；注册为 buffer，不是可训练参数。
        self.register_buffer("frequencies", 10000.0 ** (-torch.arange(0, 8, 2).float() / 8))

    def forward(self, states, cache=None):
        past_len = 0 if cache is None else cache[0].shape[2]
        normalized = self.attention_norm(states)
        Q = self.split_heads(self.query(normalized))  # [B,4,L,8]
        K = self.split_heads(self.key(normalized))
        V = self.split_heads(self.value(normalized))

        # TODO 1：生成本次输入的位置编号 [L]，从 past_len 开始。
        positions = torch.arange(past_len, past_len + Q.shape[2], dtype=torch.long, device=Q.device)
        if positions is Ellipsis:
            raise NotImplementedError("请生成带历史偏移的位置编号。")
        # TODO 2：用 apply_rope 分别旋转 Q、K；V 保持不变。
        Q_rotated, K_rotated = apply_rope(Q, positions, self.frequencies), apply_rope(K, positions, self.frequencies)
        if Q_rotated is Ellipsis or K_rotated is Ellipsis:
            raise NotImplementedError("请旋转本次输入的 Q、K。")

        if cache is not None:
            old_K, old_V = cache  # old_K 已旋转，不能再旋转。
            # TODO 3：沿序列维 dim=2 拼接历史与新 K，以及历史与新 V。
            K_rotated, V = torch.cat([old_K, K_rotated], dim=2), torch.cat([old_V, V], dim=2)
            if K_rotated is Ellipsis or V is Ellipsis:
                raise NotImplementedError("请追加新 K、V 到缓存。")

        scores = Q_rotated @ K_rotated.transpose(-2, -1) / self.head_dim ** 0.5
        future_mask = torch.ones(states.shape[1], K_rotated.shape[2],
                                 dtype=torch.bool, device=states.device).triu(past_len + 1)
        weights = scores.masked_fill(future_mask, float("-inf")).softmax(-1)
        context = (weights @ V).transpose(1, 2).reshape(states.shape[0], states.shape[1], 32)
        combined = states + self.attention_output(context)
        combined = combined + self.ffn(self.ffn_norm(combined))
        return combined, (K_rotated, V)


class RoPEModel(nn.Module):
    def __init__(self):
        super().__init__()
        self.embedding = nn.Embedding(8, 32)
        self.layers = nn.ModuleList([RoPEBlock() for _ in range(2)])
        self.final_norm = nn.LayerNorm(32)
        self.output = nn.Linear(32, 8)

    def forward(self, ids, caches=None):
        states = self.embedding(ids)  # 不再添加可学习位置 embedding。
        new_caches = []
        for i, layer in enumerate(self.layers):
            states, cache = layer(states, None if caches is None else caches[i])
            new_caches.append(cache)
        return self.output(self.final_norm(states)), new_caches


@torch.no_grad()
def main():
    torch.manual_seed(42)
    torch.set_num_threads(1)
    model = RoPEModel().eval()
    prompt = torch.tensor([[1, 2, 3, 4]])
    _, caches = model(prompt)

    # 直接核对第一层缓存：只有 K 被旋转，V 没有被旋转。
    block = model.layers[0]
    normalized = block.attention_norm(model.embedding(prompt))
    raw_k = block.split_heads(block.key(normalized))
    raw_v = block.split_heads(block.value(normalized))
    expected_k = apply_rope(raw_k, torch.arange(4), block.frequencies)
    assert torch.allclose(caches[0][0], expected_k)
    assert torch.allclose(caches[0][1], raw_v)
    print("prefill 缓存检查通过：保存已旋转 K、未旋转 V。")

    full_ids = prompt
    for token in [7, 1, 2]:
        new_id = torch.tensor([[token]])
        old_caches = caches
        cached_logits, caches = model(new_id, caches)
        full_ids = torch.cat([full_ids, new_id], dim=1)
        full_logits, full_caches = model(full_ids)
        error = (cached_logits[:, -1] - full_logits[:, -1]).abs().max().item()
        assert torch.allclose(cached_logits[:, -1], full_logits[:, -1], atol=1e-6, rtol=1e-5)
        for (old_k, old_v), (k, v), (ref_k, ref_v) in zip(old_caches, caches, full_caches):
            assert k.shape == v.shape == (1, 4, full_ids.shape[1], 8)
            assert torch.equal(k[:, :, :old_k.shape[2]], old_k)
            assert torch.equal(v[:, :, :old_v.shape[2]], old_v)
            assert torch.allclose(k, ref_k, atol=1e-6, rtol=1e-5)
            assert torch.allclose(v, ref_v, atol=1e-6, rtol=1e-5)
        print(f"前缀长度 {full_ids.shape[1]}，两条路径 logits 最大差：{error:.3g}")
    print("检查通过！这验证计算一致性，不代表模型已学会语言或可以无限扩展上下文。")


if __name__ == "__main__":
    main()
