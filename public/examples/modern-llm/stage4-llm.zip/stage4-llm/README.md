# 阶段四：现代 LLM 教学实验

本代码包随《从下一个 Token 到现代 LLM》提供，包含 AgentForge 阶段四学习代码及其本地依赖。
保留目录结构后可独立运行，不需要克隆 AgentForge，不下载模型权重。

## 环境

使用 Python 3.11 和 PyTorch。建议创建虚拟环境后安装 torch：

    python -m venv .venv
    source .venv/bin/activate
    python -m pip install torch

Windows 可使用 .venv\Scripts\activate 激活。
验证环境：Python 3.11，PyTorch 2.14.0，CPU。

## 运行

进入本 README 所在目录：

    python tutorial_examples.py
    python 04_llm/21_stage_summary/run.py

第一条执行正文数字实验；第二条验证整合模型、缓存、路由，再训练小字符模型。
01～20 的单节实验可直接运行相应 exercise.py。

正文与整合代码各有独立的教学实现，保持各自的参数约定。例如正文的 SwiGLU
使用无 bias 投影以便精确计算参数量；整合实验保留其原有配置。
最终生成模型用字符词表，BPE 为独立练习；FlashAttention 仅演示 CPU 分块原理，
MoE 仅为独立路由实验。训练 loss 不是泛化评测。

完整源码快照来自 AgentForge 提交 baed641，2026-10-10 打包。
